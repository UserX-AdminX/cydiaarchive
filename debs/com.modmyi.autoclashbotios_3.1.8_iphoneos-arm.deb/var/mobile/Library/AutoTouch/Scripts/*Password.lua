This bot was created by Harky & Jimmy Beale

u/peehead911 & u/jimmybeale



PASSWORD:  autoclashbotios