If at first you don't succeed try, try again. If you fail even after these attempts, perhaps your just stupid.
-- Devin J. Monroe (1983 - )