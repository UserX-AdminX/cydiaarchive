PLEASE READ THIS CAREFULLY.  I SPENT OVER 4 MONTHS MAKING THIS, THE LEAST YOU CAN DO IS SPEND A FEW MINUTES TO GET TO KNOW WHAT YOU ARE ABOUT TO INSTALL.


If you like iMatte and keep on using it, why not say thanks to me with a little coffee? (So to say, a little donation thru paypal will do the same ;) )
Paypal email: iconseils@gmail.com



Introduction:

iMatte v5 HD will certainly be a theme remembered for a long time.  There is 4 months (full-time, all day long work, I don't have a real job at the moment) in the making.  I first made a complete version, with ColorKeyboard, SBSettings, etc, was going to do all the extensions I support, then I realized it wasn't up to my expectations.

I then threw everything I had to the garbage bin, and restarted from scratch, and here is the result.

My initial distribution model, since I have no more website, was to go with Cydia and Theme It, and offer it to you for a 2.99$ fee.

But I'm choosing instead to offer it free to you.  I'm so confident that you will appreciate the huge amount of time and efforts that went into this that you will donate a little something, if you can.

iMatte has reached a point where I can say that I'm proud of what it looks like, and the look of it won't change no more.  It has come to conclusion.  I will keep it up to date, and do requests (upon donation).

I wish to thank the people who have donated for iMatte in the past, you are the people that made iMatte v5 possible.

I personally thank the following people: @Zooropalg, @FabriceGeib, @fifty, @jpdidde13, @invalididentity, @XPPrem, @Schmilk, @Paradox_v1, @orlandophoenix, @Zuxicovp.  You know why :)  From general advice, to moral support, inspiration, comments on twitter, donations, and parts for a broken computer, you are important people to me. Many thanks.

Also wish to thank all the nice people that participated in the public test over at MMi.  You guys have been great!  Hope to see the mods flowing!

Don't forget to visit iOSCreations.com for more awesome free stuff!

------------------------------------------------------------------------------------------------------

*** TO ALL MODDERS, if you need anything that I didn't included in the package to create a mod for iMatte, let me know.  I will provide you with whatever you need to do your thing.  Thank you much!

------------------------------------------------------------------------------------------------------

And yet one more thanks to @Zooropalg, this guy may have never released a theme of his own, but he certainly contributed to the success of many themes, iMatte included.  If you would ever leave buddy, you would be dearly missed by many.  I'm sure if you ever release a theme, it will be a monster success!



Requirements:


Technically, you can run iMatte v5 HD without any extra extension, that is beside Winterboard and it's dependencies.

For optimal use, I highly suggest you install the following extensions:

(free) Wallpaper JPEGifier, this one is actually a necessity if you want to be able to easily change the wallpaper used for the springboard html layouts
(free) WeatherIcon, this one is only needed if you want to use the Native Weather Springboard or Lockscreen theme
(free) Bytafont, if you want to use the default font bundled with iMatte, or any other fonts
(free) Zeppelin, if you want to change the Carrier Icon/Name to the custom iMatte logo or something else
(paid) Gridlock, if you don't want to deal with iBlanks and make nice layouts with the PerpageHTML+ widgets, this is highly recommended
(paid) PerpageHTML+, again, this is only if you want to use the many widgets that are made to customize your springboard beyond what Winterboard can do
(paid) ColorKeyboard, if you want to have the iOS keyboard themed, this is needed

With those tweak installed, you will be able to get iMatte exactly as you see it in screenshots.  Well, if you see a screenshots with MusicBarExtended, you will need MBEx... but you get what I mean.

Note:  If you want the mini slider like in the screenshots, this is achieved with the new SliderWidth(free) tweak on Cydia.  If you want the dock flow effect on the Springboard Dock, you can achieve with Cascade(paid) tweak.  Put together with Infinidock(paid), it makes up a pretty nice dock flow effect when scrolling to sides.



Package Summary:


-Fully themed stock iOS UI
-Full Siri theme with most of the assistants themed
-Full notification center theme
-Static springboard/lockscreen theme
-Native weather springboard/lockscreen theme (original by Subywrex, modded by me)
-Springboard slideshow
-Many handmade wallpapers + lots of hand-picked pictures for slideshows
-Customized ColorKeyboard theme with Siri support
-SBSettings theme with 37 toggles
-Full Intelliscreen (with QuickSettings) and LockInfo theme
-Auto-generating icons for AppStore apps, and lots of icons for Cydia apps included.
-Custom loading screens for all stock iOS apps, + a few Cydia/AppStore one as well. (loading screens generator script included to take care of the remaining applications that doesn't have a custom loading screens, will use a generic one)
-Lots of paid and free Cydia tweaks's settings icon done
-Customized fonts included
-PSDs included for icons, loading screens and overlays.


The following Cydia tweaks are also themed:

-AndroidLoader
-AndroidLockXT
-Anicons
-BiteSMS
-CallBar
-ColorBanner
-Deck *
-Dock
-Folder Enhancer
-FolderIcons
-Firewall IP *
-iPodControls
-Move2Unlock *
-MusicBarExtended
-PowerCenter Pro
-QuickDo
-Scrollingboard
-SlideAway
-SnowCover 4
-Twitkafly *
-WeeToolBox
-Zeppelin

(* requires you to install them manually with iFile (or WinSCP or the like), as they cannot be themed with Winterboard.  This mean you must overwrite original files, and redo everytime you update the app.  Sorry for inconvenience, not my fault.)

The following AppStore apps are themed:

-FourSquare
-Instagram
-Tweetbot
-WhatsApp

The new, free, messaging Cydia app, Handcent SMS is also themed as well.

Lots of PerPageHTML+ widgets to further customize your springboard.

Probably forgetting few things, and you can also expect some more with updates and requests as well.



Installation:


NOTE:  Summerboard option in Winterboard must be turned off.  Make sure it is disabled, otherwise you might have problems.


1. Enable the "iMatte v5 HD" theme in WinterBoard

In WinterBoard, you can optionally enable the main theme together with: 
-iMatte-Springboard
-iMatte-Lockscreen
-iMatte-Springboard SS
-iMatte-Native Weather SB
-iMatte-Native Weather LS

Note: Make sure all of these mods are listed above the main theme in WinterBoard to work right (!)

Warning: Keep in mind, that if you use the native weather theme in animated mode, it is best you don't use it on both lockscreen and springboard, as it will put quite a drain on your battery, and might make your iPhone less responsive.

If you want the flashy stuff, try to keep it on either the lockscreen or springboard, not both.



Setting Wallpapers:


Each of the springboard and lockscreen layout's wallpapers can be changed with the Settings app (Wallpaper).

Remember to use a plain background image for use as the background of the slideshow layout.  You could probably also find a suitable image to use as the background, but a plain background (gradients, textures, etc..) will work best.

Little note regarding the slideshow.  I included 20 images, but the script will only look for the first 8.  The script I found, seems to bog down a little when too many images are set in the html file.  Keep it around 8-12 for best performance.

If anyone have a better slideshow solution, that can display part of the image (I'm displaying a little less, to remove any artifact, or watermark near the edges), let me know.



Setting the widgets:


Check out the README!.txt in the appropriate theme directory for more infos.

The native weather by Subywrex don't need much configuration.  That is to display the correct weather and time.  This data comes from the first city set in the Weather app of the iPhone.  You can still configure a few things, check out the README there for more infos.

If you use the other layouts, you can set this in the ConfigureMe.js of the appropriate theme.  If you choose to use the PerpageHTML version to have the weather display only on the first springboard page and use the remaining pages otherwise, then set the widget in /var/mobile/Library/PerpageHTML/iMatte-Weather+Clock/Library/Weather/ConfigureMe.js (or the low one if you use that one instead)

There is no way to turn off the display of seconds in the digital clock script I found.  At least, not an easy way thru a settings file.  I will modify the script later to enable this option.



PerPageHTML +:


You could use the free version, but you won't be able to benefit from the cool features I came up with iMatte.

There is a bunch of PerpageHTML widgets, most of them are only overlay images, that can be applied on top of a given springboard page, to create different line patterns, dividers, docks, and icon highlights.  Plus you will find the weather+clock widget found in the Springboard theme in Winterboard.  If you want to have the widget displayed only on page 1, this is how you would do it.

Have a look inside the INSTALLATION folder, there is a PerpageHTML screens directory.  Each screenshot image is named after the PerpageHTML widget(s).

The order in perpagehtml is defined downward, meaning whatever is at the bottom, is really on top.  So if you have two things on a given page, the one at the bottom will appear on top of the other one.  Certain overlays will look better when on top of another.  Experiment, there is many possibilities.



Fonts:


Make sure you have installed BytaFont (free in Cydia), start Bytafront, press "Basic" and enable "iMatte-Neutraface-digital".  Actually, both are the same, for one minor difference, the digital version have a digital look-alike font for the dialer/calc.  By default, you should use that one, as the calculator's display have digital numbers in the background, simulating old calculator display.

If you wanna use regular neutraface for dialer/calc, or other font, look in EXTRAS for an alternate calculator display without the background numbers. 



SBSettings:


Start SBSettings, press "more", choose "dropdown window theme" and/or "notification theme" (on iOS5) and choose "iMatte"

Note:  All apps that supports themes, like lockinfo, snowcover 4, etc, have the iMatte theme in their themes list.  Go into each of those apps, and select the iMatte theme listed.



Anicons + PodControls:


Anicons and PodControls theme are included in the main theme package.

The default anicons have their icons aligned to the top position, and the PodControls have their icons aligned to the left position.

In case you want to go with an anicons bar at the top, and one at the bottom, like you see in the screenshots, you will find, individually themed anicons, that are aligned to the bottom position.

So put the default, aligned to top, anicons in the top bar (these docks are iMatte-1st, 2nd and 4th row dock in PerPageHTML+) and then, in Winterboard, select the four anicons you wish at the bottom. (ie:  iMatte-Battery-low.theme)

Same for PodControls, except they aren't in individual theme, since it wouldn't really make sense to scatter them around the screen :)  



FAQ and HELP:


* When selecting the native weather themes, the weather is stuck on loading, what can I do?
You would have need to read the readme.txt in the folder of that particular lockscreen.  But fear not, here is the solution!

Install WeatherIcon from Cydia, and respring.  Your lockscreen/springboard theme will then work like by magic. (credits to Subywrex and couple other people, you can read more in that readme)


* I have no wallpaper or lockbackground when choosing iMatte-Lockscreen or iMatte-Springboard theme, HELP!
You need to install Wallpaper JPEGifier in order to have a wallpaper displayed without any mods, with those themes (same applies with the background of the Slideshow version)

In case you don't want to install it, you will have to replace the symbolic links that are present in those theme directories.


* I made a own Lockscreen wallpaper and now my device doesn�t respring anymore ?
There seems to be a WinterBoard bug, resprings with lockscreen pictures with more than 1 MB don�t work anymore. Save your pictures for the Lockscreen at Photoshop "for web and devices" (= 24bit graphic). This reduces the size without loss of quality.

NOTE: If it�s still too large save it as a highest qualitly .jpg file. Then rename that .jpg to .png, ignore the warning and save it as "LSBG.png" to the pages Lockscreen.theme (This is needed because the code at the lockscreen theme searches for a .png graphic but displays .jpg anyway)


* "Name of Tweak" settings icon isn't themed, what do I do?
There is two possibilities.  Either the icon haven't been done yet, or the icon is not themable with Winterboard, and you have to overwrite the original with the themed one.  Have a look inside the EXTRAS folder, inside Settings Icons, and see if you find your app there.

If you do find it, copy it to the same location you see there.  I have made everything inside the EXTRAS folder exactly with the same structure on your iPhone, from root.  So you can copy the dirs/files inside a given directory inside EXTRAS, to your iphone root, and it will go to the right place.  Or you can navigate down the path, to the files, and see where it goes.


*Why do my loading screens sometimes show a black background ?
Displaying the current background only works on iOS5 and only if the app is started from springboard. Also, some apps don't come with a loading screens.  For those apps, you can look inside the EXTRAS folder for additional loading screens.  I have included a few loading screens for some Cydia apps that doesn't come with a loading screen.

In that case, you need to put the Default@2x.png inside the application folder directly.  Since there is not a Default@2x.png coming with the app, you cannot theme it simply by putting the Default@2x.png inside the Bundles of the theme dir.


* Why are my icons not aligned correctly ? 
This theme is made for the stock 4x4 icon layout. Disable other tweaks like Iconoclasm. But it�s possible to use 5 icons or more at the dock.


* Why are some of my Cydia apps icons unthemed ?
They need to be done by hand.  If you know a bit of photoshop, you can find the PSD for the icons in the EXTRAS folder of the iMatte v5 HD theme.  If you don't, you can always request it to me via the modmyi thread.


* I have the stock wallpaper when making phonecall/open a folder ?
This is because iOS will use the image set for the Lockscreen in Wallpaper inside the Settings app.  Set your desired image for lockscreen there, even if you use a lockscreen theme that set it with html.  


*How can i hide the iOS clock on Lockscreen ?
Install LockScreen ClockHide from Cydia (free)


------------------------------------------------------------------------------------------------------------------------
By Pierre-Andr� Leclair
Twitter: @myicommunity
iOSCreations: Pierre-Andr� Leclair
ModMyi: myicommunity
Paypal: iconseils@gmail.com