If you have BiteSMS, you must copy this file over the original application directory, since the original file isn't named properly (QR-Theme.plist) but instead QR-Theme.example,  so therefore, it cannot be replaced by Winterboard in Bundles.

If you don't use this theme file, the BiteSMS quick reply window text won't look right, black on dark background ;)

