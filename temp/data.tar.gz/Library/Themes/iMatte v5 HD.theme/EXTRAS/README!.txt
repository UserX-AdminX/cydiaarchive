Might be explained elsewhere, or you might figure it out, but I have organized the EXTRAS with the full path to where the files belong.

So, for example, let say you go to Alternate Calculator Display.  You will have a Library folder, inside, Themes, inside iMatte v5 HD.theme, Bundles, and so on, so follow the path until you reach the file, and you will know where it goes on your iPhone.

Every path starts from the root of your iPhone btw.  So if you think this is more troubles, you will be happy to know that you can simply enter Alternate Calculator Display, drag the Library folder that sits there to your iPhone's root, and the file will end up the right place, how cool is that? :)

To ease copying stuff from the EXTRAS, make sure you copy the folder to your computer, then drag the root folder of the extra you want to install to your iPhone's root.


 

 