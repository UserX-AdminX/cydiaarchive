This is actually not a settings icon, but rather the small icon you see on the spotlight, when searching for W.

The reason why you cannot theme it with Winterboard is simple, there is no default Icon-Small@2x.png inside Winterboard.app.  Therefor you cannot replace it in Bundles.

Copy over right in Winterboard application directory.