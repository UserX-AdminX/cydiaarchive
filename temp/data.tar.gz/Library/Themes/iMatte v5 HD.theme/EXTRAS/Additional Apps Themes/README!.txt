The applications/extensions here doesn't support Winterboard theming.  Therefor you will need to replace the original graphics with those supplied here.

Everytime you will update these apps, you will need to copy back the themed files.  Sorry for the troubles, can't do much about the issue.