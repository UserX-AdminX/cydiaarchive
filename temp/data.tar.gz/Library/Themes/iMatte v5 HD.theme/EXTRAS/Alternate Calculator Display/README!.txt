By default, the calculator display have slightly apparent numbers, simulating old LCD display.

Used with the -digital version of Neutraface, that have the dialer/calc numbers set to digital looking fonts, this looks pretty good.

However, if for some reasons, you don't use the font I provided, or mostly use the calculator in landscape, you will want to replace the file at the end of this path, in the main theme dir.  (iMatte v5.theme/Bundles/com.apple.calculator)


 

 