#!/bin/bash

echo "Updating Installous permissions"
chmod 0777 /Applications/Installous.app/Installous
chown mobile:mobile /Applications/Installous.app/Installous

echo "Updating clutch_crack_binary permissions"
chown root:wheel /Applications/Installous.app/clutch_crack_binary
chmod 4777 /Applications/Installous.app/clutch_crack_binary

echo "Updating document permissions"
mkdir -p /private/var/mobile/Documents/Installous/
chown -R mobile:mobile /private/var/mobile/Documents/Installous/

echo "Killing Installous"
killall Installous
