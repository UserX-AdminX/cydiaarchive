#!/bin/bash


# Deletes all non revision control files for the named theme.

if [ $# -eq 0 ]
then
	echo "Usage : $0 theme..." >&2
	exit 2
fi

for t in "$@"
do
	if [ ! -d "$t" ]
        then
            echo "$t is not a theme" >&2
            exit 3
        fi
done

for t in "$@"
do
	echo Emptying $t...
        find "$t" -type f | grep -v .svn | xargs rm
done
