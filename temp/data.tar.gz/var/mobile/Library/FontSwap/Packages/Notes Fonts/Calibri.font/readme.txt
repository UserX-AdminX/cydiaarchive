Calibri Font for MobileNotes iPhone 2.0.x
blog.gauravgiri.com


CAUTION: If you do not know what OpenSSH, WinSCP, root , alpine are or if you haven�t used them before, you probably shouldn�t be doing this anyway..

Step 1: Install OpenSSH from Cydia (found easily in featured apps)

Step 2: Restart iPhone

Step 3: Use WinSCP to connect to the iPhone via your IP address Username:root Password: alpine

Step 4: Download the archive and extract it to your desktop

Step 5: Navigate to the following folders on your iPhone using WinSCP or FUGU and rename the following files, adding .bak at the end [this is just a precautionary measure, you don't ever wanna lose your original files]

/System/Library/Fonts/Cache/MarkerFeltThin.ttf

copy the files in the archive in this folder, make sure each file goes where it belongs.

Step 6: Respring iPhone

Step 7: Enjoy!